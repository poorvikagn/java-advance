package com.assisted_practice_program2;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DemoJDBC
 */
@WebServlet("/DemoJDBC")
public class DemoJDBC extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DemoJDBC() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html");
	        PrintWriter out = response.getWriter();

	        try {
	            // Initialize JDBC connection
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "Gaurav@123");
	            
	            // JDBC connection successful
	            out.println("<html><body>");
	            out.println("<h2>JDBC Connection Established!</h2>");
	            out.println("</body></html>");

	            // Close JDBC connection
	            conn.close();
	        } catch (ClassNotFoundException | SQLException e) {
	            out.println("<html><body>");
	            out.println("<h2>Error establishing JDBC connection: " + e.getMessage() + "</h2>");
	            out.println("</body></html>");
	        }
	}

}
