package Jdbc;

public class Demo {

	private static final String DB_URL = "jdbc:mysql://localhost:3306/demo";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "9001";

    public static void main(String[] args) {
        Connection connection = null;
        CallableStatement callableStatement = null;

        try {
            // Step 1: Establish connection to the database
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Connected to the database.");

            // Step 2: Prepare the stored procedure call
            String storedProcedureCall = "{CALL getEmployeeById(?, ?, ?)}";
            callableStatement = connection.prepareCall(storedProcedureCall);

            // Step 3: Set input parameter for the stored procedure (employee ID)
            int employeeId = 1; // Example employee ID
            callableStatement.setInt(1, employeeId);

            // Step 4: Register output parameters for the stored procedure (employee name and email)
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.registerOutParameter(3, Types.VARCHAR);

            // Step 5: Execute the stored procedure
            callableStatement.execute();

            // Step 6: Retrieve the output parameters from the stored procedure result
            String employeeName = callableStatement.getString(2);
            String employeeEmail = callableStatement.getString(3);
            System.out.println("Employee Name: " + employeeName);
            System.out.println("Employee Email: " + employeeEmail);
        } catch (SQLException e) {
            // Handle SQL exceptions
            e.printStackTrace();
        } finally {
            // Close resources in a finally block
            try {
                if (callableStatement != null) callableStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
}
