package com.simplilearn;

public class DeleteUserServlet {

}
