package com.simplilearn;

public class SQLTestServlet {

}
