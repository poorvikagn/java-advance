package com.simplilearn;

public class User {

}
