package com.simplilearn;

public class HibernateUtil {

}
