package com.simplilearn;

public class UserDAO {

}
