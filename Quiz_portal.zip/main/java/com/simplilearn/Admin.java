package com.simplilearn;

public class Admin {

}
