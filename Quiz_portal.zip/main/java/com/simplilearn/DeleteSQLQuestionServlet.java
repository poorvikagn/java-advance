package com.simplilearn;

public class DeleteSQLQuestionServlet {

}
