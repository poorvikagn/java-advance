package com.simplilearn;

public class AdminDAO {

}
