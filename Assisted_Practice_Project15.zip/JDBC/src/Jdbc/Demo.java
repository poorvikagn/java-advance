package Jdbc;

public class Demo {

	private static final String DB_URL = "jdbc:mysql://localhost:3306/demo";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "9001";

    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;

        try {
            // Step 1: Establish connection to MySQL server
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Connected to MySQL server.");

            // Step 2: Create a new database
            createDatabase(connection);

            // Step 3: Select the newly created database
            selectDatabase(connection);

            // Step 4: Drop (delete) the database
            dropDatabase(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources in a finally block
            try {
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void createDatabase(Connection connection) throws SQLException {
        Statement statement = connection.createStatement();
        String createDatabaseSQL = "CREATE DATABASE IF NOT EXISTS " + DB_NAME;
        statement.executeUpdate(createDatabaseSQL);
        System.out.println("Database '" + DB_NAME + "' created successfully.");
    }

    private static void selectDatabase(Connection connection) throws SQLException {
        Statement statement = connection.createStatement();
        String selectDatabaseSQL = "USE " + DB_NAME;
        statement.executeUpdate(selectDatabaseSQL);
        System.out.println("Selected database: " + DB_NAME);
    }

    private static void dropDatabase(Connection connection) throws SQLException {
        Statement statement = connection.createStatement();
        String dropDatabaseSQL = "DROP DATABASE IF EXISTS " + DB_NAME;
        statement.executeUpdate(dropDatabaseSQL);
        System.out.println("Database '" + DB_NAME + "' dropped successfully.");
    }
}