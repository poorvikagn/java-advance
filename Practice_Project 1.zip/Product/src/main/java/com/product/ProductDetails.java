package com.product;
	
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;

	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	@WebServlet("/productDetails")
	public class ProductDetails extends HttpServlet {
	    private static final String DB_URL = "jdbc:mysql://localhost:3306/ProductDetails";
	    private static final String DB_USER = "root";
	    private static final String DB_PASSWORD = "9355";

	    protected void doGet(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        String productIdStr = request.getParameter("productId");
	        int productId = Integer.parseInt(productIdStr);

	        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
	            String sql = "SELECT * FROM products WHERE product_id = ?";
	            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
	                preparedStatement.setInt(1, productId);
	                try (ResultSet resultSet = preparedStatement.executeQuery()) {
	                    if (resultSet.next()) {
	                        String productName = resultSet.getString("product_name");
	                        String description = resultSet.getString("description");
	                        double price = resultSet.getDouble("price");

	                        // Display product details in HTML format
	                        response.setContentType("text/html");
	                        PrintWriter out = response.getWriter();
	                        out.println("<html><body>");
	                        out.println("<h2>Product Details</h2>");
	                        out.println("<p>Product ID: " + productId + "</p>");
	                        out.println("<p>Product Name: " + productName + "</p>");
	                        out.println("<p>Description: " + description + "</p>");
	                        out.println("<p>Price: $" + price + "</p>");
	                        out.println("</body></html>");
	                    } else {
	                        response.getWriter().println("Product not found!");
	                    }
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            response.getWriter().println("Error retrieving product details.");
	        }
	    }
	}


