package Jdbc;

public class Demo {

	private static final String DB_URL = "jdbc:mysql://localhost:3306/demo";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "9001";

    // Data to be inserted
    String studentName = "Ankit";
    int studentAge = 28;

    try (Connection conn = DriverManager.getConnection(url, username, password)) {
        System.out.println("Connected to database!");

        // SQL query to insert data
        String sql = "INSERT INTO student (name, age) VALUES (?, ?)";

        // Create a PreparedStatement
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(1, studentName);
        statement.setInt(2, studentAge);

        // Execute the insert statement
        int rowsInserted = statement.executeUpdate();
        if (rowsInserted > 0) {
            System.out.println("A new student was inserted successfully!");
        }

    } catch (SQLException e) {
        System.err.println("Error inserting data: " + e.getMessage());
    }
}

}
