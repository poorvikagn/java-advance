package com.assisted_project;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class HttpSessionServlet
 */
@WebServlet("/HttpSessionServlet")
public class HttpSessionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HttpSessionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		 response.setContentType("text/html");

	        // Create a new session or retrieve existing session
	        HttpSession session = request.getSession(true);

	        // Retrieve the session ID
	        String sessionId = session.getId();

	        response.getWriter().println("<html><body>");
	        response.getWriter().println("<h1>Session Tracking using HTTP Session</h1>");
	        response.getWriter().println("<p>Session ID: " + sessionId + "</p>");
	        response.getWriter().println("</body></html>");
	}

}
