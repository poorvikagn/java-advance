package com.assisted_project;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Cookies
 */
@WebServlet("/Cookies")
public class Cookies extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Cookies() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");

        // Create a new cookie
        Cookie cookie = new Cookie("username", "raju");

        // Set the maximum age of the cookie to 1 hour (3600 seconds)
        cookie.setMaxAge(3600);

        // Add the cookie to the response
        response.addCookie(cookie);

        response.getWriter().println("<html><body>");
        response.getWriter().println("<h1>Session Tracking using Cookies</h1>");
        response.getWriter().println("<p>Cookie has been set with username: raju</p>");
        response.getWriter().println("</body></html>");
    }
}

