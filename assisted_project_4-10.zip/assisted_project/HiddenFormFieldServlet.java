package com.assisted_project;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class HiddenFormFieldServlet
 */
@WebServlet("/HiddenFormFieldServlet")
public class HiddenFormFieldServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HiddenFormFieldServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");

        // Create a new session or retrieve existing session
        HttpSession session = request.getSession(true);

        // Generate a random session ID
        String sessionId = session.getId();

        response.getWriter().println("<html><body>");
        response.getWriter().println("<h1>Session Tracking using Hidden Form Fields</h1>");
        response.getWriter().println("<p>Hidden form field containing session ID has been generated:</p>");
        response.getWriter().println("<form action='NextPageServlet' method='post'>");
        response.getWriter().println("<input type='hidden' name='sessionId' value='" + sessionId + "'>");
        response.getWriter().println("<input type='submit' value='Proceed to Next Page'>");
        response.getWriter().println("</form>");
        response.getWriter().println("</body></html>");
	}

}
